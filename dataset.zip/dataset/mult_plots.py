import os
import numpy as np
from scipy.io import wavfile
from scipy.fftpack import fft
from scipy.io import wavfile as wav
import matplotlib.pyplot as plt
 
directory = "/home/pi/audios_folder/recording_multi_fils"
pattern = "_speed_1000rpm"


plt.figure(figsize=(12, 6))

for filename in os.listdir(directory):
    if filename.endswith(".wav") and pattern in filename:
        print (filename)

        filepath = os.path.join(directory, filename)
        sample_rate, data = wavfile.read(filepath)
        N=len(data)
        spectre=fft(data)
        freq=np.fft.fftfreq(N,1/sample_rate)
        mask= freq>0
    
        plt.plot(freq[mask],np.abs(spectre[mask]),label=filename)
     


plt.title("FFT of All WAV Files")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Amplitude")
plt.legend(bbox_to_anchor=(1.05,1),loc='upper left')
plt.xlim(0,1000)
plt.tight_layout()
plt.grid()
plt.show()
