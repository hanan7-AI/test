recording_multi_fils.py --> This file is to recored multiple audio files with different speed and unbalanc weights
aslo to plot FFT for each .wav file.

mult_plots.py --> To plot FFT for all wav fils in the folder

plot_fft_and_wav.py --> To plot FFT with audio signal