
from scipy.fftpack import fft
from scipy.io import wavfile as wav
import matplotlib.pyplot as plt
import numpy as np

file_name="./recording_multi_fils/run_1_unbalweight_0mg_speed_3000rpm.wav"
sample_rate, data = wav.read(file_name)
N=len(data)
spectre=fft(data)
freq=np.fft.fftfreq(N,1/sample_rate)
mask= freq>0


plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
time_axis=np.linspace(0,len(data) / sample_rate, len(data))
plt.plot(time_axis,data)
plt.title('WAV Signal')
plt.xlabel('Time(s)')
plt.ylabel('Amplitude')


plt.subplot(1,2,2)
plt.plot(freq[mask],np.abs(spectre[mask]))
#plt.plot(np.abs(spectre))
plt.title('FFT')
plt.xlabel('Frequency')
plt.ylabel('Amplitude')
plt.xlim(0,1000)
plt.tight_layout()
plt.show()
