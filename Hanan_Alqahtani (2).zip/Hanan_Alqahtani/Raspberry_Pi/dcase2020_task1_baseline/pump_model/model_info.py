import numpy as np
import tflite_runtime.interpreter as tflite
import os
import common as com  

# Load the TFLite model and allocate tensors
model_path = "model_pump_new.tflite"
interpreter = tflite.Interpreter(model_path)
interpreter.allocate_tensors()

# Get input and output details
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

print("input info" ,input_details )
print("output info" ,output_details)
