baseline.yaml --> To load parameters from the configuration file 

Common.py --> Extract features from the audio file 

model_info.py --> Get input and output details

model.tflite --> Model after converting to TensorFlow-Lite model

pump_model_inference.py --> To run the model. 