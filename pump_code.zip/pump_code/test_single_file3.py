import numpy as np
import tflite_runtime.interpreter as tflite
import common as com
from common import yaml_load, file_to_vector_array  # Import from common.py

def get_anomaly_score_tflite(model_path, audio_file_path):
    
    # 01 Load TFLite model and allocate tensors
    interpreter = tflite.Interpreter(model_path=model_path)
    interpreter.allocate_tensors()

    # 02 Get input and output details
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    
    # 03 Extract features with the same parameters as the training process
    param = com.yaml_load()

    data = file_to_vector_array(
        file_name=audio_file_path,
        n_mels=param['feature']['n_mels'],
        frames=param['feature']['frames'],
        n_fft=param['feature']['n_fft'],
        hop_length=param['feature']['hop_length'],
        power=param['feature']['power']
    )

    # Prepare the data for input into the model
    data = np.expand_dims(data, axis=0).astype(np.float32) 
    
    # Set the tensor for input data
    interpreter.set_tensor(input_details[0]['index'], data.astype(np.float32))

    # Run inference
    interpreter.invoke()
    
    
    # Calculate the reconstruction error to get the anomaly score
    errors = np.mean(np.square(data - prediction), axis=1)
    anomaly_score = np.mean(errors)

    # Output the anomaly score
    com.logger.info(f"Anomaly score for file {audio_file_path}: {anomaly_score}")
    return anomaly_score
 

# Example usage
model_path = "pump_model.tflite"
audio_file_path = "anomaly_id_00_00000000.wav"
output = get_anomaly_score_tflite(model_path, audio_file_path)
print("Output:", output)
