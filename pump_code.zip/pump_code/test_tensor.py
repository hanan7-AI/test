import numpy as np
import tflite_runtime.interpreter as tflite

model_path = "model_pump_new.tflite"
tensor=np.zeros((1,640),dtype=np.float32)
print(tensor)
interpreter = tflite.Interpreter(model_path)
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

interpreter.set_tensor(input_details[0]['index'], tensor)
interpreter.invoke()

output= interpreter.get_tensor(output_details[0]['index'])
print(output)
print(output.shape)

